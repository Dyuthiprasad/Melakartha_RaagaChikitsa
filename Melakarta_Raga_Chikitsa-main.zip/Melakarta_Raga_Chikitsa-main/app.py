from flask import Flask, render_template, request, send_from_directory, redirect, url_for
import os
import random
from datetime import datetime
import pandas as pd
from prediction import predict_raga


app = Flask(__name__)


@app.route('/', methods=['POST', 'GET'])
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form["email"]
        pwd = request.form["pwd"]

        users_df = pd.read_excel('user.xlsx')

        for index, row in users_df.iterrows():
            if row["email"] == email and row["password"] == pwd:

                return redirect(url_for('home'))

        error_message = 'Invalid email or password. Please try again.'
        return render_template('login.html', msg=error_message)

    else:
        return render_template('login.html')


# Static folder path where music files are stored
STATIC_FOLDER = os.path.join(os.getcwd(), 'static', 'input')


# Define the intersect filter
@app.template_filter('intersect')
def intersect(list1, list2):
    return list(set(list1) & set(list2))

# Register the filter
app.jinja_env.filters['intersect'] = intersect


@app.route('/home', methods=['GET', 'POST'])
def home():
    selected_time = None
    selected_folders = []
    music_files = {}
    raga_info = []

    if request.method == 'POST':
        try:
            selected_time = request.form['input_time']
            print("selected_time: ", selected_time)
            if selected_time:
                selected_folders, raga_info = get_folders_based_on_time(selected_time)
                print("selected_folders: ", selected_folders)
                print("raga_info: ", raga_info)
                music_files = get_random_music_files(selected_folders)
                print("music_files: ", music_files)
        except KeyError as e:
            print(f"KeyError: {str(e)}")

    return render_template('index.html', selected_time=selected_time, selected_folders=selected_folders, music_files=music_files, raga_info=raga_info)


def get_folders_based_on_time(selected_time):
    # Define the time ranges, set names, and corresponding folder names
    time_folder_mapping = {
        (datetime.strptime('03:00', '%H:%M'), datetime.strptime('06:00', '%H:%M')): ('Ahoratra (Early Morning)', ['Kanakangi', 'Ratnangi', 'Ganamurti', 'Vanaspati', 'Manavati', 'Tanarupi']),
        (datetime.strptime('06:00', '%H:%M'), datetime.strptime('09:00', '%H:%M')): ('Pratah (Morning)', ['Senavati', 'Hanumatodi', 'Dhenuka', 'Natakapriya', 'Kokilapriya', 'Rupavati', 'Gayakapriya', 'Vakulabharanam', 'Mayamalavagowla', 'Chakravakam', 'Suryakantam', 'Hatakambari']),
        (datetime.strptime('09:00', '%H:%M'), datetime.strptime('15:00', '%H:%M')): ('Madhyahna (Midday)', ['Jhankaradhvani', 'Naṭabhairavi', 'Kiravani', 'Kharaharapriya', 'Gourimanohari', 'Varunapriya', 'Mararanjani', 'Charukesi', 'Sarasangi', 'Harikambhōji', 'Dhirasankarabharanam', 'Naganandini', 'Yagapriya', 'Ragavardhini', 'Gangeyabhusani', 'Vagadhisvari', 'Sulini', 'Chalanaṭa']),
        (datetime.strptime('15:00', '%H:%M'), datetime.strptime('18:00', '%H:%M')): ('Sayankala (Evening)', ['Salagam', 'Jalarnavam', 'Jhalavarali', 'Navanitam', 'Pavani', 'Raghupriya', 'Gavambhodi', 'Bhavapriya', 'Subhapantuvarali', 'Shadvidamargini', 'Suvarnangi', 'Divyamani', 'Dhavalambari', 'Namanarayani', 'Kamavardhini', 'Ramapriya', 'Gamanasrama', 'Visvambari']),
        (datetime.strptime('18:00', '%H:%M'), datetime.strptime('21:00', '%H:%M')): ('Pradosha (Early Night)', ['Samalangi', 'Sanmukhapriya', 'Simhendramadhyamam', 'Hemavati']),
        (datetime.strptime('21:00', '%H:%M'), datetime.strptime('23:59', '%H:%M')): ('Nishitha (Late Night)', ['Dharmavati', 'Nitimati', 'Kantamani', 'Risabhapriya', 'Latangi', 'Vachaspati', 'Mechakalyani', 'Chitrambari']),
        (datetime.strptime('00:00', '%H:%M'), datetime.strptime('03:00', '%H:%M')): ('Ratri Pradosha (Midnight to Early Morning)', ['Sucharitra', 'Jyoti svarupini', 'Dhathuvardhani', 'Nasikabhusani', 'Kōsalam', 'Rasikapriya'])
    }

    selected_time_obj = datetime.strptime(selected_time, '%H:%M').time()
    selected_folders = []
    raga_info = []

    for (start_time, end_time), (set_name, ragas) in time_folder_mapping.items():
        if start_time.time() <= selected_time_obj <= end_time.time():
            selected_folders = ragas
            raga_info.append({
                'set_name': set_name,
                'start_time': start_time.strftime('%H:%M'),
                'end_time': end_time.strftime('%H:%M'),
                'ragas': ragas
            })
            break

    return selected_folders, raga_info


def get_random_music_files(selected_folders):
    music_files = {}
    for folder in selected_folders:
        folder_path = os.path.join(STATIC_FOLDER, folder)
        music_files[folder] = get_random_music_file(folder_path)
    return music_files

def get_random_music_file(folder_path):
    music_files = [f for f in os.listdir(folder_path) if f.endswith('.wav')]
    if music_files:
        random_music_file = random.choice(music_files)
        print(f"Selected music file: {random_music_file}")  # Add this line for debugging
        return os.path.join('input', os.path.basename(folder_path), random_music_file).replace('\\', '/')
    return None


UPLOAD_FOLDER = 'static/uploads'
# Add other allowed audio file extensions
ALLOWED_EXTENSIONS = {'wav'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/play/<filename>')
def play_audio(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file_ip = request.files['file']

        if file_ip and allowed_file(file_ip.filename):
            # Save the uploaded file to the 'static/uploaded' directory
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_ip.filename)
            file_ip.save(file_path)

            file_path = file_path.replace('\\', '/')

            raga_detection = predict_raga(file_path)

            return render_template('upload.html', raga_name=raga_detection, audio_path=file_ip.filename)
        else:
            raga_error = "Invalid file format. Please upload a valid audio file."
            return render_template('upload.html', raga_name=raga_error)
        
    return render_template('upload.html')


@app.route('/register', methods=['POST', 'GET'])
def register():
    try:
        if request.method == 'POST':
            email = request.form['email']
            pwd = request.form['pwd']
            repwd = request.form['repwd']
            if pwd == repwd:  # Fix the comparison operator
                col_list = ["email", "password"]
                try:
                    # Try reading the existing file, if it exists
                    r1 = pd.read_excel('user.xlsx', usecols=col_list)
                except FileNotFoundError:
                    # If the file doesn't exist, create an empty DataFrame
                    r1 = pd.DataFrame(columns=col_list)

                new_row = {'email': email, 'password': pwd}
                r1 = r1.append(new_row, ignore_index=True)
                r1.to_excel('user.xlsx', index=False)
                print("Records created successfully")
                msg = 'Registration Successful. You can log in here.'
                return render_template('login.html', msg=msg)
            else:
                msg = 'Password and Re-enter password do not match.'
                return render_template('register.html', msg=msg)
        return render_template('register.html')
    except:
        return render_template('register.html', msg="Please Enter valid mail pattern like xyz@gmail.com")


@app.route('/password', methods=['POST', 'GET'])
def password():
    try:
        if request.method == 'POST':
            current_pass = request.form['current']
            new_pass = request.form['new']
            verify_pass = request.form['varify']
            r1 = pd.read_excel('user.xlsx')
            for index, row in r1.iterrows():
                if row["password"] == str(current_pass):
                    if new_pass == verify_pass:
                        r1.loc[index, "password"] = verify_pass
                        r1.to_excel("user.xlsx", index=False)
                        msg1 = 'Password changed successfully'
                        return render_template('password.html', msg=msg1)
                    else:
                        msg = 'Re-entered password is not matched'
                        return render_template('password.html', msg=msg)
            else:
                msg3 = 'Incorrect Password'
                return render_template('password.html', msg=msg3)
        return render_template('password.html')
    except Exception as e:
        return render_template('password.html', msg=e)


@app.route('/logout')
def logout():
    return render_template("login.html")

    
if __name__ == '__main__':
    app.run(debug=True)
